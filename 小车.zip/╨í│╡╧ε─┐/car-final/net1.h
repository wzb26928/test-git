#ifndef __NET1_H__
#define __NET1_H__
	int init_net1();
	int do_work1(int connfd1);
	
#endif
